# All The Ciphers

A Python library and command-line tool built from the original `encripter v2.1.py` single-file cipher toolkit.

It includes classical ciphers, encodings, novelty systems, SmartGuess, and brute-force helpers.

## Install from GitHub

```bash
pip install git+https://github.com/YOUR-USERNAME/all-the-ciphers.git
```

For local development:

```bash
git clone https://github.com/YOUR-USERNAME/all-the-ciphers.git
cd all-the-ciphers
python -m pip install -e .
```

## Python usage

```python
from all_the_ciphers import encode, decode, list_ciphers, smart_guess

ct = encode("Caesar", "HELLO WORLD", shift=3)
print(ct)  # KHOOR ZRUOG

pt = decode("Caesar", ct, shift=3)
print(pt)  # HELLO WORLD

print(list_ciphers()[:10])
print(smart_guess("Gur dhvpx oebja sbk")[:3])
```

## CLI usage

```bash
python -m all_the_ciphers list
python -m all_the_ciphers encode Caesar "HELLO WORLD" -p shift=3
python -m all_the_ciphers decode Caesar "KHOOR ZRUOG" -p shift=3
python -m all_the_ciphers guess "Gur dhvpx oebja sbk"
```

After installation, these commands also work:

```bash
encripter list
all-the-ciphers list
```

## GitHub Pages website

This repo includes `docs/index.html`. In GitHub:

1. Open the repository settings.
2. Go to **Pages**.
3. Set **Source** to **Deploy from a branch**.
4. Select branch `main` and folder `/docs`.
5. Save.

Your website will be available at:

```text
https://YOUR-USERNAME.github.io/all-the-ciphers/
```

For a user site like `https://YOUR-USERNAME.github.io/`, put the files in a repository named exactly `YOUR-USERNAME.github.io`.

## Notes

This project is for educational use with classical ciphers and encodings. It is not a replacement for modern authenticated encryption libraries such as `cryptography`.
