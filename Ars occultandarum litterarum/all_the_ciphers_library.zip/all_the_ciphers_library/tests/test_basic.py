from all_the_ciphers import decode, encode, list_ciphers


def test_caesar_roundtrip():
    ct = encode("Caesar", "HELLO", shift=3)
    assert ct == "KHOOR"
    assert decode("Caesar", ct, shift=3) == "HELLO"


def test_registry_not_empty():
    assert "Caesar" in list_ciphers()
